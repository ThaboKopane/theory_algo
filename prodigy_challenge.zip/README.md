Hello thank you for reading my README.

I was confused about standard libraries.
Q1: I used pandas to manipulate the csv
Q2: I used linear programming, and thus required external dependencies.


question 2 runs on a Mac only.
question 1 was only tested on Mac.
The output for question 1 is only 90% correct, due to the algorithm I use to compare
Contents of an array and a pandas data frame -the are repeated numbers but the number of Max loans and sum is correct. - even the array is correct.

Python 3.6.5

Before start: brew install glpk #for the maximisation function in simplex.

Everything else will be installed when required